﻿
namespace Project
{
    partial class AddMember
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.nameTxtbox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dateOfMembershipTxtbox = new System.Windows.Forms.TextBox();
            this.booksBorrowedTxtbox = new System.Windows.Forms.TextBox();
            this.bookLimitTxtbox = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.surnameTxtbox = new System.Windows.Forms.TextBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.SuspendLayout();
            // 
            // nameTxtbox
            // 
            this.nameTxtbox.Location = new System.Drawing.Point(24, 32);
            this.nameTxtbox.Name = "nameTxtbox";
            this.nameTxtbox.Size = new System.Drawing.Size(231, 20);
            this.nameTxtbox.TabIndex = 0;
            this.toolTip1.SetToolTip(this.nameTxtbox, "Enter member name");
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 115);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Date of Membership:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Member Name :";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 169);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(140, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Number of Books Borrowed:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 223);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Book Limit:";
            // 
            // dateOfMembershipTxtbox
            // 
            this.dateOfMembershipTxtbox.Location = new System.Drawing.Point(25, 131);
            this.dateOfMembershipTxtbox.Name = "dateOfMembershipTxtbox";
            this.dateOfMembershipTxtbox.Size = new System.Drawing.Size(231, 20);
            this.dateOfMembershipTxtbox.TabIndex = 5;
            this.toolTip1.SetToolTip(this.dateOfMembershipTxtbox, "Enter date of membership");
            // 
            // booksBorrowedTxtbox
            // 
            this.booksBorrowedTxtbox.Location = new System.Drawing.Point(25, 185);
            this.booksBorrowedTxtbox.Name = "booksBorrowedTxtbox";
            this.booksBorrowedTxtbox.Size = new System.Drawing.Size(231, 20);
            this.booksBorrowedTxtbox.TabIndex = 6;
            this.toolTip1.SetToolTip(this.booksBorrowedTxtbox, "Enter number of books borrowed");
            // 
            // bookLimitTxtbox
            // 
            this.bookLimitTxtbox.Location = new System.Drawing.Point(25, 239);
            this.bookLimitTxtbox.Name = "bookLimitTxtbox";
            this.bookLimitTxtbox.Size = new System.Drawing.Size(231, 20);
            this.bookLimitTxtbox.TabIndex = 7;
            this.toolTip1.SetToolTip(this.bookLimitTxtbox, "Enter book limit");
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(24, 284);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(231, 34);
            this.button2.TabIndex = 8;
            this.button2.Text = "Add Member";
            this.toolTip1.SetToolTip(this.button2, "Click to add member ");
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(23, 65);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(96, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Member Surname :";
            // 
            // surnameTxtbox
            // 
            this.surnameTxtbox.Location = new System.Drawing.Point(25, 81);
            this.surnameTxtbox.Name = "surnameTxtbox";
            this.surnameTxtbox.Size = new System.Drawing.Size(231, 20);
            this.surnameTxtbox.TabIndex = 9;
            this.toolTip1.SetToolTip(this.surnameTxtbox, "Enter member surname");
            // 
            // AddMember
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(286, 341);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.surnameTxtbox);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.bookLimitTxtbox);
            this.Controls.Add(this.booksBorrowedTxtbox);
            this.Controls.Add(this.dateOfMembershipTxtbox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.nameTxtbox);
            this.Name = "AddMember";
            this.Text = "AddMember";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox nameTxtbox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox dateOfMembershipTxtbox;
        private System.Windows.Forms.TextBox booksBorrowedTxtbox;
        private System.Windows.Forms.TextBox bookLimitTxtbox;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox surnameTxtbox;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}