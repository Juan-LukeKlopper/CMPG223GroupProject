﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Project
{
    public partial class MembershipForm : Form
    {
        public MembershipForm()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection();
        SqlDataAdapter adap;
        DataSet ds;
        SqlCommand comm;
        string connectionstring = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Shaun\Documents\CMPG223\Project\Project\Membership.mdf;Integrated Security=True";
        
        public void loadAll()
        {

            conn = new SqlConnection(connectionstring);
            conn.Open();
            adap = new SqlDataAdapter();
            ds = new DataSet();

            string sql = "SELECT * FROM MembershipTable";

            comm = new SqlCommand(sql, conn);
            adap.SelectCommand = comm;
            adap.Fill(ds, "MembershipTable");

            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "MembershipTable";

            conn.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            
            try
            {
                conn = new SqlConnection(connectionstring);

                string delete_query = "DELETE FROM MembershipTable WHERE MEMBER_NAME ='" + textBox2.Text + "'";
                conn.Open();
                SqlCommand cmd = new SqlCommand(delete_query, conn);
                SqlDataAdapter adapter = new SqlDataAdapter();
                adapter.DeleteCommand = cmd;
                adapter.DeleteCommand.ExecuteNonQuery();

                conn.Close();
                MessageBox.Show("Record deleted");
                textBox2.Text = "";
               
                loadAll();
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            AddMember addMember = new AddMember();
            addMember.ShowDialog();
            loadAll();
        }

        private void searchBox_TextChanged(object sender, EventArgs e)
        {
            
            try
            {
                conn.Open();
                adap = new SqlDataAdapter();
                ds = new DataSet();

                string sql = @"SELECT * FROM MembershipTable WHERE MEMBER_NAME LIKE '%" + searchBox.Text + "%'";

                SqlCommand comm = new SqlCommand(sql, conn);

                adap.SelectCommand = comm;
                adap.Fill(ds, "MembershipTable");

                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "MembershipTable";

                conn.Close();
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }

        }

        private void MembershipForm_Load(object sender, EventArgs e)
        {
            loadAll();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
